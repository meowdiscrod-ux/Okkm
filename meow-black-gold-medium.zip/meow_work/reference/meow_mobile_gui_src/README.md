# Meow Mobile GUI — C++ / Dear ImGui

A mobile-friendly recreation of the supplied Minecraft client GUI reference.

## What is included
- C++ GUI renderer built around Dear ImGui.
- Five module panels: Combat, Movement, Render, Misc, Client.
- Top tabs, search field, pink selected states, rounded translucent panels.
- Responsive layout: on narrow screens the five panels remain accessible through
  horizontal touch scrolling instead of becoming unreadably tiny.
- Android NDK CMake starter.

## Integration
This is the GUI layer, not a complete Minecraft client or injector. Your client
must call `MeowGui::Render(...)` every frame from its existing Android/OpenGL ES
render loop and forward Android touch events to the ImGui Android backend.

Add Dear ImGui to `app/src/main/cpp/third_party/imgui/` (or change the include
paths in CMakeLists.txt). Also add the Dear ImGui Android and OpenGL ES 3
backend source files:
- `backends/imgui_impl_android.cpp`
- `backends/imgui_impl_opengl3.cpp`

The host app/client must initialize the ImGui context and backends once, then
call `MeowGui::Render(displayWidth, displayHeight)` each frame between
`ImGui_ImplOpenGL3_NewFrame()` / `ImGui_ImplAndroid_NewFrame()` and
`ImGui::Render()` / `ImGui_ImplOpenGL3_RenderDrawData()`.

## Blur note
The reference uses a blurred game image behind the panels. ImGui does not blur
the already-rendered game by itself. This project uses translucent glass-like
panels. For the same true background blur, connect a lightweight downsampled
blur pass in the host renderer and draw the GUI over that texture.

## Build
Use Android Studio / Android NDK with CMake. Configure the Dear ImGui source
path in `app/src/main/cpp/CMakeLists.txt`. The CMake file is a starter and
expects the ImGui dependency to be supplied by the integrating client project.
