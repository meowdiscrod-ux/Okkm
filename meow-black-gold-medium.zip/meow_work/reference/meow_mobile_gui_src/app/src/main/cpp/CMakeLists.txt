cmake_minimum_required(VERSION 3.22.1)
project(meow_mobile_gui LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Point this at the Dear ImGui checkout used by your client.
set(IMGUI_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party/imgui")

add_library(meow_mobile_gui STATIC
    MeowGui.cpp
)

target_include_directories(meow_mobile_gui PUBLIC
    "${CMAKE_CURRENT_SOURCE_DIR}"
    "${IMGUI_DIR}"
)

# The integrating client should compile/link the ImGui core and Android/OpenGL3
# backend sources in its existing native target.
find_library(log-lib log)
target_link_libraries(meow_mobile_gui PUBLIC ${log-lib})
