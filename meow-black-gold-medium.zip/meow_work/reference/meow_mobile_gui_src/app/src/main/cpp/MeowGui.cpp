#include "MeowGui.h"
#include "imgui.h"
#include <algorithm>
#include <string>
#include <vector>

namespace {
struct Module {
    const char* name;
    bool enabled;
    bool expandable;
};

struct Category {
    const char* name;
    std::vector<Module> modules;
};

static std::vector<Category> BuildCategories() {
    return {
        {"Combat", {
            {"Aim Assist", false, true}, {"Auto Anchor", false, true},
            {"Auto Crystal", false, true}, {"Auto Mace", true, true},
            {"AutoCart", false, true}, {"AutoTool", false, true},
            {"Backtrack", false, true}, {"Hitboxes", false, true},
            {"Mace Swap", false, true}, {"ShieldBreaker", false, true},
            {"Spear Lunge", true, true}, {"Spear Reach", false, true},
            {"Totem Hit", false, true}, {"Trigger Bot", false, true}
        }},
        {"Movement", {
            {"Auto Walk", false, true}, {"Combo Helper", false, true},
            {"Fast Stairs", false, true}, {"Freecam", false, true},
            {"GUI Walk", false, true}, {"Jump Reset", false, true},
            {"Keep Sprint", false, true}, {"Move Fix", true, true},
            {"No Jump Delay", false, true}, {"No Lunge Cooldown", false, true},
            {"No Slow", false, true}, {"No Web", false, true},
            {"NoFall", false, true}, {"Null Move", false, true},
            {"Speed", false, true}, {"Sprint", false, true},
            {"Step", false, true}, {"Timer", false, true}, {"Velocity", false, true}
        }},
        {"Render", {
            {"Aim Visualizer", false, true}, {"Crosshair", false, true},
            {"FullBright", false, true}, {"Gloss Panel", false, true},
            {"Hit Markers", false, true}, {"HUD", true, true},
            {"Jump Circles", false, true}, {"Nametags", false, true},
            {"NoHurtCam", false, true}, {"NoRender", false, true},
            {"Player ESP", true, true}, {"Storage ESP", false, true},
            {"Swing Speed", false, true}, {"Target HUD", true, true},
            {"Trails", false, true}, {"Trajectories", false, true}, {"Zoom", false, true}
        }},
        {"Misc", {
            {"InvPreview", false, true}, {"Targets", true, true}, {"Teams", false, true}
        }},
        {"Client", {
            {"Liquid Glass", true, false}, {"UI Sounds", true, false}, {"GUI Style", false, true}
        }}
    };
}

static ImVec4 Pink()       { return ImVec4(0.88f, 0.72f, 0.31f, 1.00f); }
static ImVec4 Panel()      { return ImVec4(0.035f, 0.035f, 0.035f, 0.88f); }
static ImVec4 PanelHover() { return ImVec4(0.15f, 0.14f, 0.11f, 0.92f); }
static ImVec4 Text()       { return ImVec4(0.94f, 0.94f, 0.94f, 0.98f); }

static void ApplyStyle(float scale) {
    ImGuiStyle& s = ImGui::GetStyle();
    s = ImGuiStyle();
    s.ScaleAllSizes(scale);
    s.WindowRounding = 15.0f * scale;
    s.ChildRounding = 14.0f * scale;
    s.FrameRounding = 10.0f * scale;
    s.PopupRounding = 10.0f * scale;
    s.ScrollbarRounding = 10.0f * scale;
    s.WindowBorderSize = 0.0f;
    s.ChildBorderSize = 1.0f * scale;
    s.FrameBorderSize = 0.0f;
    s.ItemSpacing = ImVec2(7.0f * scale, 7.0f * scale);
    s.FramePadding = ImVec2(10.0f * scale, 7.0f * scale);

    ImVec4* c = s.Colors;
    c[ImGuiCol_Text] = Text();
    c[ImGuiCol_WindowBg] = ImVec4(0.08f, 0.08f, 0.11f, 0.0f);
    c[ImGuiCol_ChildBg] = Panel();
    c[ImGuiCol_Border] = ImVec4(0.82f, 0.78f, 0.88f, 0.18f);
    c[ImGuiCol_FrameBg] = ImVec4(0.18f, 0.17f, 0.23f, 0.72f);
    c[ImGuiCol_FrameBgHovered] = PanelHover();
    c[ImGuiCol_FrameBgActive] = ImVec4(0.36f, 0.25f, 0.34f, 0.88f);
    c[ImGuiCol_Button] = ImVec4(0.20f, 0.18f, 0.25f, 0.12f);
    c[ImGuiCol_ButtonHovered] = PanelHover();
    c[ImGuiCol_ButtonActive] = ImVec4(0.45f, 0.28f, 0.39f, 0.9f);
    c[ImGuiCol_Header] = ImVec4(0.94f, 0.39f, 0.69f, 0.90f);
    c[ImGuiCol_HeaderHovered] = ImVec4(0.98f, 0.52f, 0.77f, 0.95f);
    c[ImGuiCol_HeaderActive] = Pink();
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.08f, 0.08f, 0.11f, 0.12f);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(0.80f, 0.70f, 0.82f, 0.35f);
    c[ImGuiCol_CheckMark] = Pink();
}

static bool ModuleRow(Module& m, const char* id, float scale, const std::string& filter) {
    if (!filter.empty()) {
        std::string a = m.name, b = filter;
        std::transform(a.begin(), a.end(), a.begin(), ::tolower);
        std::transform(b.begin(), b.end(), b.begin(), ::tolower);
        if (a.find(b) == std::string::npos) return false;
    }

    ImGui::PushID(id);
    const float h = 32.0f * scale;
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImVec2 sz(ImGui::GetContentRegionAvail().x, h);
    ImDrawList* dl = ImGui::GetWindowDrawList();

    if (m.enabled) {
        dl->AddRectFilled(p, ImVec2(p.x + sz.x, p.y + sz.y), ImGui::ColorConvertFloat4ToU32(Pink()), 8.0f * scale);
    }
    ImGui::InvisibleButton("##row", sz);
    if (ImGui::IsItemClicked()) m.enabled = !m.enabled;

    ImU32 txt = ImGui::ColorConvertFloat4ToU32(m.enabled ? ImVec4(1,1,1,1) : Text());
    dl->AddText(ImVec2(p.x + 10.0f * scale, p.y + 8.0f * scale), txt, m.name);
    if (m.expandable) {
        const char* mark = "+";
        ImVec2 ts = ImGui::CalcTextSize(mark);
        dl->AddText(ImVec2(p.x + sz.x - ts.x - 10.0f * scale, p.y + 8.0f * scale),
                    ImGui::ColorConvertFloat4ToU32(ImVec4(0.88f,0.84f,0.91f,0.8f)), mark);
    } else if (std::string(m.name) == "GUI Style") {
        // The reference shows a small style selector on this row.
        dl->AddRectFilled(ImVec2(p.x + sz.x - 78.0f*scale, p.y + 5.0f*scale),
                          ImVec2(p.x + sz.x - 8.0f*scale, p.y + 27.0f*scale),
                          IM_COL32(35,31,43,230), 7.0f*scale);
        dl->AddText(ImVec2(p.x + sz.x - 68.0f*scale, p.y + 9.0f*scale),
                    IM_COL32(245,240,248,255), "Dropdown");
    }
    ImGui::PopID();
    return true;
}

static void DrawCategory(Category& cat, int index, float scale, float height, const std::string& filter) {
    ImGui::PushID(index);
    ImGui::BeginChild(cat.name, ImVec2(194.0f * scale, height), true,
                      ImGuiWindowFlags_AlwaysUseWindowPadding);
    ImGui::TextUnformatted(cat.name);
    ImGui::Dummy(ImVec2(0, 2.0f * scale));
    for (size_t i = 0; i < cat.modules.size(); ++i) {
        ModuleRow(cat.modules[i], cat.name, scale, filter);
        ImGui::Dummy(ImVec2(0, 1.0f * scale));
    }
    ImGui::EndChild();
    ImGui::PopID();
}
}

namespace MeowGui {
void Render(float displayWidth, float displayHeight) {
    static std::vector<Category> categories = BuildCategories();
    static int selectedTab = 0;
    static char search[96] = {};
    static bool opened = true;

    if (!opened || displayWidth <= 0 || displayHeight <= 0) return;

    const float scale = std::clamp(displayWidth / 1200.0f, 0.72f, 1.0f);
    ApplyStyle(scale);

    const float margin = 16.0f * scale;
    const float top = 12.0f * scale;
    const float panelHeight = std::max(220.0f * scale, displayHeight - 2.0f * margin - 90.0f * scale);
    const float maxWidth = std::min(displayWidth - 2.0f * margin, 1080.0f * scale);

    ImGui::SetNextWindowPos(ImVec2(margin, top), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(maxWidth, displayHeight - top - margin), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.0f);
    ImGui::Begin("##MeowRoot", &opened,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground |
        ImGuiWindowFlags_NoBringToFrontOnFocus);

    // Header/navigation bar.
    ImGui::SetCursorPosX(std::max(0.0f, (maxWidth - 510.0f * scale) * 0.5f));
    ImGui::BeginChild("##nav", ImVec2(510.0f * scale, 42.0f * scale), true);
    const char* tabs[] = {"Modules", "HUD", "Friends", "Theme", "Config", "Donut"};
    for (int i = 0; i < 6; ++i) {
        if (i) ImGui::SameLine(0, 2.0f * scale);
        ImGui::PushID(i);
        if (selectedTab == i) {
            ImGui::PushStyleColor(ImGuiCol_Button, Pink());
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.18f,0.13f,0.19f,1));
        }
        if (ImGui::Button(tabs[i], ImVec2(i == 0 ? 94.0f : 68.0f, 28.0f * scale))) selectedTab = i;
        if (selectedTab == i) ImGui::PopStyleColor(2);
        ImGui::PopID();
    }
    ImGui::EndChild();

    // Search field.
    ImGui::SetCursorPosX(std::max(0.0f, (maxWidth - 320.0f * scale) * 0.5f));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 8.0f * scale);
    ImGui::SetNextItemWidth(320.0f * scale);
    ImGui::InputTextWithHint("##search", "Search modules...", search, sizeof(search));

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 12.0f * scale);

    // Keep the reference's five-column layout. On phones this region is touch-scrollable.
    ImGui::BeginChild("##module_columns",
        ImVec2(maxWidth, panelHeight), false,
        ImGuiWindowFlags_HorizontalScrollbar);
    for (int i = 0; i < (int)categories.size(); ++i) {
        if (i) ImGui::SameLine(0, 10.0f * scale);
        DrawCategory(categories[i], i, scale, panelHeight - 8.0f * scale, search);
    }
    ImGui::EndChild();

    ImGui::End();
}
}
