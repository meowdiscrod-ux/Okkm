#pragma once

namespace MeowGui {
    // Call from the client's existing ImGui/OpenGL ES render frame.
    void Render(float displayWidth, float displayHeight);
}
