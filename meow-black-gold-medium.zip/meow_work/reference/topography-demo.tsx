"use client"

// Reference only (animate-ui TopographyBackground demo). The Java port lives in MeowGuiScreen.java (drawTopo / rebuildTopo).
import { TopographyBackground } from "@/components/animate-ui/backgrounds/topography"

export default function TopographyBackgroundDemo({
  lineColor = "",
  levels = 16,
  speed = 1,
  scale = 1,
  peak = 1,
  interactive = true,
}: {
  lineColor?: string
  levels?: number
  speed?: number
  scale?: number
  peak?: number
  interactive?: boolean | string
}) {
  return (
    <TopographyBackground
      className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,#fafafa_0%,#f0f0f0_100%)] text-neutral-500 dark:bg-[radial-gradient(ellipse_at_center,#171717_0%,#000_100%)] dark:text-neutral-400"
      lineColor={lineColor || undefined}
      levels={Number(levels)}
      speed={Number(speed)}
      scale={Number(scale)}
      peak={Number(peak)}
      interactive={interactive === true || interactive === "true"}
    />
  )
}
