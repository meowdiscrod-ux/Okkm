package cc.mochi.meowgui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;

/**
 * Drawing adapter for the Meow GUI. Every Minecraft draw call lives here.
 * Shapes are built from plain fills only, so they render on any GPU / GL translation layer
 * (including the GLES wrappers used by Android launchers).
 */
public final class Gfx {
    private static DrawContext ctx;
    private static final Map<String, Text> TEXT_CACHE = new HashMap<>();
    private static final Map<String, Text> BOLD_CACHE = new HashMap<>();

    private Gfx() {}

    public static void begin(DrawContext c) { ctx = c; }

    // ---- text ----
    private static Text text(String s) {
        if (TEXT_CACHE.size() > 2048) TEXT_CACHE.clear();
        return TEXT_CACHE.computeIfAbsent(s, Text::literal);
    }
    private static Text boldText(String s) {
        if (BOLD_CACHE.size() > 512) BOLD_CACHE.clear();
        return BOLD_CACHE.computeIfAbsent(s, k -> Text.literal(k).formatted(Formatting.BOLD));
    }
    private static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }
    public static int textWidth(String s) { return tr().getWidth(text(s)); }
    public static void text(String s, int x, int y, int color) {
        // vanilla treats a near-zero alpha as fully opaque, so skip instead of drawing
        if ((color >>> 24) < 8) return;
        ctx.drawText(tr(), text(s), x, y, color, false);
    }
    public static int boldWidth(String s) { return tr().getWidth(boldText(s)); }
    public static void bold(String s, int x, int y, int color) {
        if ((color >>> 24) < 8) return;
        ctx.drawText(tr(), boldText(s), x, y, color, false);
    }
    public static void textCentered(String s, int cx, int y, int color) { text(s, cx - textWidth(s) / 2, y, color); }
    public static String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (textWidth(s) <= maxW) return s;
        while (s.length() > 1 && textWidth(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
    public static void scissor(int x, int y, int w, int h) { ctx.enableScissor(x, y, x + Math.max(0, w), y + Math.max(0, h)); }
    public static void unscissor() { ctx.disableScissor(); }

    // ---- colour helpers (ARGB ints) ----
    public static int rgba(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
    public static int mulA(int argb, float f) {
        int a = (int) ((argb >>> 24) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (argb & 0xFFFFFF);
    }
    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) ((c1 >>> 24) + ((c2 >>> 24) - (c1 >>> 24)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    /** HSB -> 0xRRGGBB, no java.awt (not guaranteed on mobile JREs). */
    public static int hsb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1 - Math.abs((h * 6) % 2 - 1)), m = v - c;
        float r, g, b;
        int sector = (int) (h * 6);
        switch (sector) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    // ---- mixed-colour helpers ----
    /** Three-stop gradient colour at t in 0..1. */
    public static int grad3(int c1, int c2, int c3, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t < 0.5f ? lerp(c1, c2, t * 2f) : lerp(c2, c3, (t - 0.5f) * 2f);
    }
    /** Perceived brightness 0..255 of an RGB colour. */
    public static int luminance(int rgb) {
        return (int) (0.299f * ((rgb >> 16) & 255) + 0.587f * ((rgb >> 8) & 255) + 0.114f * (rgb & 255));
    }
    /** Horizontal gradient as a few slices (few fills, cheap). */
    public static void gradientBar(int x, int y, int w, int h, int c1, int c2, int seg) {
        if (w <= 0 || h <= 0 || seg < 1) return;
        for (int i = 0; i < seg; i++) {
            int x0 = x + i * w / seg, x1 = x + (i + 1) * w / seg;
            rect(x0, y, x1 - x0, h, lerp(c1, c2, (i + 0.5f) / seg));
        }
    }
    public static void gradientBar3(int x, int y, int w, int h, int c1, int c2, int c3, int seg) {
        if (w <= 0 || h <= 0 || seg < 1) return;
        for (int i = 0; i < seg; i++) {
            int x0 = x + i * w / seg, x1 = x + (i + 1) * w / seg;
            rect(x0, y, x1 - x0, h, grad3(c1, c2, c3, (i + 0.5f) / seg));
        }
    }
    /** Text that fades from c1 to c2 (up to 4 chunks, so at most 4 draw calls). */
    public static void gradientText(String s, int x, int y, int c1, int c2) {
        int len = s.length();
        if (len == 0) return;
        int chunks = Math.min(4, len);
        int cx = x;
        for (int k = 0; k < chunks; k++) {
            String part = s.substring(len * k / chunks, len * (k + 1) / chunks);
            if (part.isEmpty()) continue;
            text(part, cx, y, lerp(c1, c2, (k + 0.5f) / chunks));
            cx += textWidth(part);
        }
    }

    // ---- primitives ----
    public static void rect(int x, int y, int w, int h, int c) {
        if (w > 0 && h > 0 && (c >>> 24) > 0) ctx.fill(x, y, x + w, y + h, c);
    }
    private static int inset(int row, int h, int r) {
        if (r <= 0) return 0;
        double d;
        if (row < r) d = r - row - 0.5;
        else if (row >= h - r) d = row - (h - r) + 0.5;
        else return 0;
        return Math.max(0, (int) Math.ceil(r - Math.sqrt(Math.max(0, r * r - d * d)) - 0.3));
    }

    // Every ctx.fill() is a separate GUI element for the renderer, so the FEWER fills a frame has the
    // faster it is (this matters a lot on phones). Shapes below merge rows that share the same edge
    // into one fill: a rounded rect is ~6 fills instead of ~16, an outline ~20 instead of ~2 per row.
    private static final int[][] CORNER = new int[40][];
    private static int[] corner(int r) {
        if (r >= CORNER.length) { int[] a = new int[r]; for (int i = 0; i < r; i++) a[i] = inset(i, 2 * r, r); return a; }
        int[] a = CORNER[r];
        if (a == null) { a = new int[r]; for (int i = 0; i < r; i++) a[i] = inset(i, 2 * r, r); CORNER[r] = a; }
        return a;
    }

    public static void roundRect(int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0 || (c >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { rect(x, y, w, h, c); return; }
        int[] in = corner(r);
        // top corner rows, grouped by equal inset
        int k = 0;
        while (k < r) {
            int o = in[k], k2 = k;
            while (k2 + 1 < r && in[k2 + 1] == o) k2++;
            rect(x + o, y + k, w - 2 * o, k2 - k + 1, c);
            k = k2 + 1;
        }
        rect(x, y + r, w, h - 2 * r, c);
        // bottom corner rows (mirror of the top)
        k = r - 1;
        while (k >= 0) {
            int o = in[k], k2 = k;
            while (k2 - 1 >= 0 && in[k2 - 1] == o) k2--;
            rect(x + o, y + h - 1 - k, w - 2 * o, k - k2 + 1, c);
            k = k2 - 1;
        }
    }

    private static void outlineRow(int x, int y, int w, int h, int r, int t, int c, int row) {
        int o = inset(row, h, r);
        if (row < t || row >= h - t) { rect(x + o, y + row, w - 2 * o, 1, c); return; }
        int in = Math.max(o, t + inset(row - t, h - 2 * t, Math.max(0, r - t)));
        rect(x + o, y + row, in - o, 1, c);
        rect(x + w - in, y + row, in - o, 1, c);
    }

    public static void roundOutline(int x, int y, int w, int h, int r, int t, int c) {
        if (w <= 0 || h <= 0 || (c >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        int m = Math.max(r, t);
        if (h < 2 * m + 1) {
            for (int row = 0; row < h; row++) outlineRow(x, y, w, h, r, t, c, row);
            return;
        }
        // only the corner rows need per-row work; the straight sides are two tall fills
        for (int row = 0; row < m; row++) {
            outlineRow(x, y, w, h, r, t, c, row);
            outlineRow(x, y, w, h, r, t, c, h - 1 - row);
        }
        rect(x, y + m, t, h - 2 * m, c);
        rect(x + w - t, y + m, t, h - 2 * m, c);
    }

    public static void circle(int cx, int cy, int r, int c) {
        if (r < 0 || (c >>> 24) == 0) return;
        int dy = 0;
        while (dy <= r) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            int dy2 = dy;
            while (dy2 + 1 <= r && (int) Math.round(Math.sqrt(Math.max(0, r * r - (dy2 + 1) * (dy2 + 1) + r * 0.4))) == half) dy2++;
            if (dy == 0) {
                rect(cx - half, cy - dy2, half * 2, dy2 * 2 + 1, c);
            } else {
                rect(cx - half, cy + dy, half * 2, dy2 - dy + 1, c);
                rect(cx - half, cy - dy2, half * 2, dy2 - dy + 1, c);
            }
            dy = dy2 + 1;
        }
    }
    public static void ring(int cx, int cy, int r, int t, int c) {
        int ir = r - t;
        for (int dy = -r; dy <= r; dy++) {
            int oh = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            if (Math.abs(dy) >= ir) { rect(cx - oh, cy + dy, oh * 2, 1, c); continue; }
            int ih = (int) Math.round(Math.sqrt(Math.max(0, ir * ir - dy * dy)));
            rect(cx - oh, cy + dy, oh - ih, 1, c);
            rect(cx + ih, cy + dy, oh - ih, 1, c);
        }
    }
}
