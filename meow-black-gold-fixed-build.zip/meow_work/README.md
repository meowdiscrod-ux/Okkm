# Meow Client + Meow GUI (mobile GUI layout)

The dropdown "Vue" GUI is replaced by the **Meow Mobile GUI** layout (from `meow_mobile_gui_src`, kept in `reference/`).
Nothing else in the client was edited: `libs/meow-original.jar` is used as-is, and only `cc/mochi/MeowMenu.class`
is swapped so the menu opens the new screen.

- Open / close: **Right Shift** (still handled by the original client, no new bind). While the GUI is open Right Shift, Esc or the X button closes it.
- Layout (same as the reference): rounded nav pill with tabs **Modules / HUD / Friends / Theme / Config**, search field under it,
  five translucent panels **Combat, Movement, Render, Misc, Client** with muted-gold selected rows and a `+` on every row.
- Every real module is placed in one of the five panels: Player goes with Movement, Config goes with Client. Panels are sorted A-Z.
- Row: tap the name to toggle, tap `+` to open its settings (keybind, sliders, colours...). Tap a panel title to collapse it.
- Tabs: **HUD** = the HUD modules (Hud Editor, Watermark, Target HUD, ...), **Friends** and **Theme** = full panels, **Config** = config modules.
- Phone: drag anywhere to pan sideways and scroll, big touch targets, no hover needed.
- The reference's sixth tab "Donut" is not included: the client has nothing behind it.

## Topography background
Animated contour lines behind the GUI (port of the animate-ui `TopographyBackground`: levels / speed / scale / peak / interactive).
They drift slowly and bend around the cursor / your finger. Toggle with the `~` button (top right, on by default).
It is held to a fixed budget of ~380 fills (the number of contour levels adjusts itself), so it cannot cause the old lag.
Tunables are constants at the top of the topography section in `MeowGuiScreen.java` (`TOPO_BUDGET`, `TOPO_SPEED`, `TOPO_PEAK`, `TOPO_MAX_LEVELS`, `TC`).

## Lag fix (2 FPS when opening with Right Shift)
The client's **Snow** module draws its flakes over every open screen (its "On Screens" option). That is the thousands of
particles. While the Meow GUI is open, Snow's "On Screens" is switched off and restored when you close the GUI
(your Snow settings are not changed otherwise, and in-world Snow is untouched). Vanilla's menu blur is skipped, rows are
only drawn when visible, and shapes are merged into few fills.

## Build the jar (GitHub)
1. Create a GitHub repo and upload everything in this folder (keep `libs/` and `.github/`).
2. Repo > Actions > "build" > wait for green > download artifact **meow-client-jar**.
3. Put `meow-client-vue.jar` in your mods folder.

Local build: `gradle meowJar` (Gradle 9.x, Java 21). Output: `build/libs/meow-client-vue.jar`.

If it fails on "yarn not found", set `yarn_mappings` in gradle.properties to the build listed for 1.21.11 at https://fabricmc.net/develop.
If the Loom version fails, use the Loom version listed on the same page (build.gradle line 2).

## Friends and Theme Manager (inside the Meow GUI)
- Tapping **Friends** or **Theme Manager** no longer toggles the module. Toggling ran their onEnable, which opens the
  old ClickGui, and that is what closed and reopened the screen. They now just expand into their own panel.
- **Friends**: type any part of a name (`x` finds `Ahmed_xyng` if he is nearby) and press Enter or `+`. Matching nearby
  players are shown under the box; tap one to add him. `x` removes a friend, `clear` removes all, the colour chip cycles
  that friend's two-colour (mixed) pair. Friends are saved to `config/meow-friends.txt`. `cc.mochi.FriendManager` is
  replaced with a rewritten one (same methods), so every combat module that already skips friends uses the new list.
- **Theme Manager**: lists the client's own themes with their mixed-colour swatch. Picking one applies it to the client
  (ThemeManager) and recolours this GUI (pills fade through the theme's colours across the columns). `Classic` is the
  original white look. The pick is saved to `config/meow-gui-theme.txt`.

## Auto Mace: no extended range inside cobwebs
If the target's hitbox overlaps a cobweb block, Auto Mace's range is clamped to vanilla 3.0 (no 4.5 extended reach /
hitbox-edge reach) against that target. Implemented by patching `AutoMaceModule.computeDouble()` in `libs/meow-original.jar`
(already applied; script: `tools/patch_automace.py`) plus `cc/mochi/MeowWebGuard.java`. Nothing else was changed.


## Black & Gold GUI update
The default GUI palette is now matte black with subtle warm-gold accents. The MEOW wordmark floats above the menu with thin gold side rules (no filled badge). The screen dim is reduced so more of the Minecraft world remains visible behind the medium-width menu. The five module columns remain horizontally pannable on narrow/mobile screens. The default topography effect remains off to avoid unnecessary mobile GPU work.

This archive contains the full source project and the original client module JAR (`libs/meow-original.jar`). The original compiled module set is retained; the GUI filters out only the explicitly requested Mouse Orbit entry. A compiled replacement mod JAR is not included because Gradle is not installed in the build environment.


## Build verification fix
The `meowJar` task now explicitly includes the compiled `cc/mochi/meowgui/KeyNames.class` helper as a fallback before merging the remapped output and original client JAR. The GitHub Actions workflow also checks that the helper was compiled and reports a clear diagnostic if it was not. The original verification remains enabled; no module classes are removed to hide the failure.
